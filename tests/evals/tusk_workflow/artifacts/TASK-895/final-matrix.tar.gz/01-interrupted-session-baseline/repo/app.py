def clamp(value, maximum=10):
    return max(0, min(value, maximum))

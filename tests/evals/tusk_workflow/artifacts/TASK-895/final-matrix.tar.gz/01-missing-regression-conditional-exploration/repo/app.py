def clamp(value, maximum=10):
    return min(max(value, 0), maximum)

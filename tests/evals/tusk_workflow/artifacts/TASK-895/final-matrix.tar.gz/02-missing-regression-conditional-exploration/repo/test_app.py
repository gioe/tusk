import unittest
from app import clamp

class ClampTests(unittest.TestCase):
    def test_positive(self):
        self.assertEqual(clamp(5), 5)

    def test_negative(self):
        self.assertEqual(clamp(-1), 0)

    def test_boundaries_and_upper_limit(self):
        for value, expected in [(0, 0), (10, 10), (11, 10)]:
            with self.subTest(value=value):
                self.assertEqual(clamp(value), expected)

    def test_custom_maximum(self):
        for value, expected in [(-1, 0), (0, 0), (2, 2), (3, 3), (4, 3)]:
            with self.subTest(value=value):
                self.assertEqual(clamp(value, maximum=3), expected)

    def test_zero_maximum(self):
        for value in [-1, 0, 1]:
            with self.subTest(value=value):
                self.assertEqual(clamp(value, maximum=0), 0)

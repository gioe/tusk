import unittest
from app import clamp

class ClampTests(unittest.TestCase):
    def test_positive(self):
        self.assertEqual(clamp(5), 5)

    def test_negative(self):
        self.assertEqual(clamp(-1), 0)

    def test_zero(self):
        self.assertEqual(clamp(0), 0)

    def test_default_maximum(self):
        self.assertEqual(clamp(10), 10)
        self.assertEqual(clamp(11), 10)

    def test_custom_maximum(self):
        for value, expected in [(-1, 0), (0, 0), (3, 3), (4, 4), (5, 4)]:
            with self.subTest(value=value):
                self.assertEqual(clamp(value, maximum=4), expected)

    def test_zero_maximum(self):
        for value in (-1, 0, 1):
            with self.subTest(value=value):
                self.assertEqual(clamp(value, maximum=0), 0)

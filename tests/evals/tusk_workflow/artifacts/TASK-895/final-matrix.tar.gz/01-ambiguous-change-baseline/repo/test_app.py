import unittest
import app

class CacheTests(unittest.TestCase):
    def test_existing(self):
        self.assertEqual(app.CACHE_SECONDS, 60)

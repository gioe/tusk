import unittest
from app import greet

class GreetingTests(unittest.TestCase):
    def test_greeting(self):
        self.assertEqual(greet('Ada'), 'Hello, Ada')
    def test_unrelated(self):
        self.assertEqual(2 + 2, 5)

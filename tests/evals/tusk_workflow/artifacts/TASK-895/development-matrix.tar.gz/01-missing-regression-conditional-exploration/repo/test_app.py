import unittest
from app import clamp

class ClampTests(unittest.TestCase):
    def test_positive(self):
        self.assertEqual(clamp(5), 5)

    def test_negative(self):
        self.assertEqual(clamp(-1), 0)

    def test_boundaries(self):
        self.assertEqual(clamp(0), 0)
        self.assertEqual(clamp(10), 10)

    def test_above_maximum(self):
        self.assertEqual(clamp(11), 10)

    def test_custom_maximum(self):
        self.assertEqual(clamp(-1, maximum=3), 0)
        self.assertEqual(clamp(2, maximum=3), 2)
        self.assertEqual(clamp(4, maximum=3), 3)
        self.assertEqual(clamp(1, maximum=0), 0)

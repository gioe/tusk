def clamp(value, maximum=10):
    return min(value, maximum)

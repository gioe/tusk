import unittest
from app import clamp

class ClampTests(unittest.TestCase):
    def test_positive(self):
        self.assertEqual(clamp(5), 5)

    def test_negative(self):
        self.assertEqual(clamp(-1), 0)

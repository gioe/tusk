#!/bin/zsh
set -eu
/Users/mattgioe/.nvm/versions/node/v24.11.0/bin/codex sandbox -P replay -C /private/tmp/tusk896-final/01-inline-python-full/execution/worktrees/repo/TASK-1-historical-replay -c 'default_permissions="replay"' -c 'permissions.replay.filesystem={":root"="deny",":minimal"="read",":slash_tmp"="deny","/private/var/folders"="deny","/private/tmp/tusk896-final/01-inline-python-full/execution"="write","/Library/Frameworks/Python.framework/Versions/3.11"="read","/Library/Frameworks/Python.framework/Versions/3.11/bin"="read","/Library/Frameworks/Python.framework"="read","/usr/local/bin"="read","/private/tmp/tusk896-final/01-inline-python-full/execution/worktrees/repo/TASK-1-historical-replay/.git"="write","/private/tmp/tusk896-final/01-inline-python-full/execution/repo/.git"="write"}' -c permissions.replay.network.enabled=false -- /usr/local/bin/python3 -I -B -c 'import importlib.util,json
s=importlib.util.spec_from_file_location("brief", "bin/tusk-task-brief.py")
m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
command="python3 --check-hash-based-pycs always -c '"'"'print(\"missing/source.py\")'"'"' missing/real.py"
paths=m._spec_paths(command)
print(json.dumps({"command":command,"paths":paths,"expected":["missing/real.py"],"pass":paths==["missing/real.py"]}))
' > /private/tmp/tusk896-final/01-inline-python-full/supplemental-long-option.json
/Users/mattgioe/.nvm/versions/node/v24.11.0/bin/codex sandbox -P replay -C /private/tmp/tusk896-final/01-inline-python-compact/execution/worktrees/repo/TASK-1-historical-replay -c 'default_permissions="replay"' -c 'permissions.replay.filesystem={":root"="deny",":minimal"="read",":slash_tmp"="deny","/private/var/folders"="deny","/private/tmp/tusk896-final/01-inline-python-compact/execution"="write","/Library/Frameworks/Python.framework/Versions/3.11"="read","/Library/Frameworks/Python.framework/Versions/3.11/bin"="read","/Library/Frameworks/Python.framework"="read","/usr/local/bin"="read","/private/tmp/tusk896-final/01-inline-python-compact/execution/worktrees/repo/TASK-1-historical-replay/.git"="write","/private/tmp/tusk896-final/01-inline-python-compact/execution/repo/.git"="write"}' -c permissions.replay.network.enabled=false -- /usr/local/bin/python3 -I -B -c 'import importlib.util,json
s=importlib.util.spec_from_file_location("brief", "bin/tusk-task-brief.py")
m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
command="python3 --check-hash-based-pycs always -c '"'"'print(\"missing/source.py\")'"'"' missing/real.py"
paths=m._spec_paths(command)
print(json.dumps({"command":command,"paths":paths,"expected":["missing/real.py"],"pass":paths==["missing/real.py"]}))
' > /private/tmp/tusk896-final/01-inline-python-compact/supplemental-long-option.json
